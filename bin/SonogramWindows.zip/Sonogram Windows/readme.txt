1.) You have to be Java at least in version 16 installed on your computer.
2.) You can start Sonogram with a doubleclick on the Sonoram.jar file.
3.) Alternatively you can start Sonogram with the command:
   java -splash:bin/de/dfki/sonogram/Splash.png -showversion -Xms128m -Xmx1536m --add-opens=java.desktop/sun.awt=ALL-UNNAMED -jar Sonogram.jar
4.) Add java to the PATH environment variable.
